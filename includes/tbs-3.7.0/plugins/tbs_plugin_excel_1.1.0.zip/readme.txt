TinyButStrong plug-in for Excel

Files :

- tbs_plugin_excel.php : TBS plug-in for Excel
- tbs_plugin_excel.htm : help file
- empty.xls            : an empty template file

- demo.php             : run the demo
- demo_*.*             : files requiered for the demo
- tbs_class.php        : the TBS engine required to run the demo

- readme.txt           : this file