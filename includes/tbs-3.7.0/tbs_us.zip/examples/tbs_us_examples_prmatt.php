<?php

include_once('tbs_class.php');

$x_color = '#8FC2ED';
$x_style = 'style2';
$x_nostyle = '';

$TBS = new clsTinyButStrong;
$TBS->LoadTemplate('tbs_us_examples_prmatt.htm');
$TBS->Show();

?>